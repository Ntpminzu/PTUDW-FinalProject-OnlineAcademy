import express from 'express';

const router = express.Router();

router.get('/list', function (req, res) {
    res.render('Admin/UserList');
});

router.get('/user/edit', function (req, res) {
    res.render('Admin/UserEdit');
});

router.get('/user/add', function (req, res) {
    res.render('Admin/UserAdd');
} );

export default router;